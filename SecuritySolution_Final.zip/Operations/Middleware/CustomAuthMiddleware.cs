namespace Operations.Middleware{
public class CustomAuthMiddleware{
 private readonly RequestDelegate _n;
 public CustomAuthMiddleware(RequestDelegate n){_n=n;}
 public async Task Invoke(HttpContext c){
  await _n(c);
 }}}
