using Microsoft.EntityFrameworkCore;
using Operations.Data;
using Operations.Middleware;
using Operations.Services;

var builder=WebApplication.CreateBuilder(args);
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddScoped<AuthService>();
builder.Services.AddDbContext<AppDbContext>(o=>o.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
var app=builder.Build();
app.UseSwagger();
app.UseSwaggerUI();
app.UseMiddleware<CustomAuthMiddleware>();
app.MapControllers();
app.Run();